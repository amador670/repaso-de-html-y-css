# Changelog

## Version 1.0.0

+ Basic plugin