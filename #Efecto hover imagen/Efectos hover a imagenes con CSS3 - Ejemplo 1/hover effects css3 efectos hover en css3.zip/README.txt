A Pen created at CodePen.io. You can find this one at http://codepen.io/ramonigimenez/pen/XJNxNQ.

 Dos ejemplos de hover en css3, uno de ellos básico y el otro un poco más avanzado.