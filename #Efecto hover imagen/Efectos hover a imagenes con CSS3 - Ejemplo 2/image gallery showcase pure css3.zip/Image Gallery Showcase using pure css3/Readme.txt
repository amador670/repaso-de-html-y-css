Hello Friend,

Thank You for Downloading the Source Code from

-----------------------------------------------
		WWW.WEB3CANVAS.com
-----------------------------------------------


You are free to Use on your Personal on Commercial Site.
You can also reSale this Source with your Ownership for free.


YOU Can Download more Source code like this, 

Please Visit www.web3canvas.com or visit blog.web3canvas.com
	     ------------------          -------------------





-----------------------------------------------
		HOPE YOU ENJOY
-----------------------------------------------