# Changelog

## Version 1.0.4

+ HTML Attribute `data-fancyIndex-hide` added
+ HTML Attribute `data-fancyIndex-title` added

## Version 1.0.3

+ Option `flipPosition` added